-- ============================================================
-- Fire a Web Push whenever anyone records an action (action_log insert).
-- Run ONCE in SQL Editor AFTER deploying the push-action Edge Function.
-- Replace REPLACE_WITH_YOUR_CRON_SECRET with the SAME value you used for
-- the CRON_SECRET function secret (the one you set for push-tick).
-- ============================================================

create extension if not exists pg_net;

create or replace function notify_action()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  perform net.http_post(
    url     := 'https://djynxtuobkysisgtpkek.supabase.co/functions/v1/push-action',
    headers := jsonb_build_object(
                 'Content-Type', 'application/json',
                 'x-cron-secret', 'REPLACE_WITH_YOUR_CRON_SECRET'
               ),
    body    := jsonb_build_object('detail', NEW.action_detail, 'client_id', NEW.client_id)
  );
  return NEW;
end;
$$;

drop trigger if exists trg_notify_action on action_log;
create trigger trg_notify_action
  after insert on action_log
  for each row execute function notify_action();

-- To stop it later:  drop trigger trg_notify_action on action_log;
