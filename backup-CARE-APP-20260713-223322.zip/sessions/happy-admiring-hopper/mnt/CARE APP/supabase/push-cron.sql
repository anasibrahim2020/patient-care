-- ============================================================
-- Schedule the push-tick Edge Function to run every minute.
-- Run this ONCE in Supabase → SQL Editor AFTER you have:
--   1) deployed the push-tick Edge Function, and
--   2) set its secrets (VAPID_* + CRON_SECRET).
-- Replace REPLACE_WITH_YOUR_CRON_SECRET below with the SAME value
-- you set for the CRON_SECRET function secret.
-- ============================================================

create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Remove any previous schedule (safe to re-run)
do $$ begin perform cron.unschedule('push-tick'); exception when others then null; end $$;

select cron.schedule('push-tick', '* * * * *', $$
  select net.http_post(
    url     := 'https://djynxtuobkysisgtpkek.supabase.co/functions/v1/push-tick',
    headers := jsonb_build_object(
                 'Content-Type', 'application/json',
                 'x-cron-secret', 'REPLACE_WITH_YOUR_CRON_SECRET'
               ),
    body    := '{}'::jsonb
  );
$$);

-- To check it is scheduled:      select * from cron.job;
-- To see recent runs:            select * from cron.job_run_details order by start_time desc limit 20;
-- To stop it:                    select cron.unschedule('push-tick');
