// Supabase Edge Function: push-tick
// Invoked every minute by pg_cron. Works out which reminders are due
// (meds / feeding / vitals / Vitamin D) for the current Qatar-time minute
// and sends a Web Push to every registered device.
//
// Required Function secrets (Dashboard → Edge Functions → push-tick → Secrets):
//   VAPID_PUBLIC_KEY   — the public key (same one baked in index.html)
//   VAPID_PRIVATE_KEY  — the private key (keep secret)
//   VAPID_SUBJECT      — e.g. mailto:you@example.com
//   CRON_SECRET        — any random string; cron must send it in the x-cron-secret header
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided automatically.

import webpush from "npm:web-push@3.6.7";
import { createClient } from "jsr:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VAPID_PUBLIC = Deno.env.get("VAPID_PUBLIC_KEY")!;
const VAPID_PRIVATE = Deno.env.get("VAPID_PRIVATE_KEY")!;
const VAPID_SUBJECT = Deno.env.get("VAPID_SUBJECT") || "mailto:care@careportal.com";
const CRON_SECRET = Deno.env.get("CRON_SECRET") || "";

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
const sb = createClient(SUPABASE_URL, SERVICE_KEY);

// Slot times (Qatar local HH:MM) — mirror of the app schedule.
const MED_TIMES = ["06:00", "08:00", "12:00", "13:00", "18:00", "20:00", "00:00"]; // slots containing a real drug
const REPO_TIMES = ["00:00", "04:00", "07:00", "12:00", "16:00", "20:00"]; // repositioning (every 4h, some overlap with meds)
const VITALS_TIMES = ["06:00", "14:00", "22:00"];
// Fixed date-based reminders (Qatar date). Update as needed.
const DATE_REMINDERS = [
  { date: "2026-08-06", ar: { title: "تذكير: صرف/تجديد الأدوية", body: "صرف/تجديد الأدوية من المستشفى" }, en: { title: "Reminder: medication refill", body: "Refill medications from the hospital" } },
  { date: "2026-08-13", ar: { title: "تذكير: تغيير أنبوب NGT", body: "موعد تغيير أنبوب NGT" }, en: { title: "Reminder: NGT change", body: "Time to change the NGT tube" } },
  { date: "2026-09-08", ar: { title: "تذكير: تغيير T-Tube", body: "متابعة أنف وأذن — تغيير T-Tube" }, en: { title: "Reminder: T-Tube change", body: "ENT follow-up — T-Tube change" } },
];
type Msg = { title: string; body: string };
type Due = { ar: Msg; en: Msg; tag: string };

const p2 = (n: number) => String(n).padStart(2, "0");

Deno.serve(async (req) => {
  if (CRON_SECRET && req.headers.get("x-cron-secret") !== CRON_SECRET) {
    return new Response("forbidden", { status: 403 });
  }

  // Current time in Qatar (UTC+3, no DST)
  const q = new Date(Date.now() + 3 * 3600 * 1000);
  const cur = `${p2(q.getUTCHours())}:${p2(q.getUTCMinutes())}`;
  const todayQ = q.toISOString().slice(0, 10);

  const due: Due[] = [];

  const isMed = MED_TIMES.includes(cur), isRepo = REPO_TIMES.includes(cur);
  if (isMed && isRepo) due.push({ ar: { title: "موعد أدوية + تغيير وضعية 💊", body: `الساعة ${cur} — أعطِ الأدوية وغيّر وضعية المريض` }, en: { title: "Meds + reposition 💊", body: `${cur} — give the meds and reposition the patient` }, tag: "med" });
  else if (isMed) due.push({ ar: { title: "موعد أدوية 💊", body: `الساعة ${cur} — افتح التطبيق لعرض الأدوية` }, en: { title: "Medication due 💊", body: `${cur} — open the app to view the meds` }, tag: "med" });
  else if (isRepo) due.push({ ar: { title: "موعد تغيير الوضعية 🔄", body: "حان وقت تغيير وضعية المريض" }, en: { title: "Reposition due 🔄", body: "Time to reposition the patient" }, tag: "care" });
  if (VITALS_TIMES.includes(cur)) due.push({ ar: { title: "موعد قياس المؤشرات", body: "سجّل: الحرارة والضغط والنبض والأكسجين والسكر" }, en: { title: "Vitals check due", body: "Record: temp, BP, pulse, SpO₂, glucose" }, tag: "vitals" });

  // Feeding times from app_state (first-session time set by the nurse)
  const { data: st } = await sb.from("app_state").select("k,v").in("k", ["sh", "sm", "vitD_next"]);
  const map: Record<string, unknown> = Object.fromEntries((st || []).map((r: any) => [r.k, r.v]));
  const sh = Number(map.sh ?? 6), sm = Number(map.sm ?? 0);
  for (let i = 0; i < 6; i++) {
    const tot = (sh * 60 + sm) + i * 240;
    const t = `${p2(Math.floor(tot / 60) % 24)}:${p2(tot % 60)}`;
    if (t === cur) due.push({ ar: { title: `موعد تغذية — الجلسة ${i + 1} 🍽️`, body: "ابدأ الجلسة — إجلاس المريض بزاوية 40–45°" }, en: { title: `Feeding — Session ${i + 1} 🍽️`, body: "Start the session — seat patient at 40–45°" }, tag: "feed" });
    // Water is given ~2h after the feed starts — its own separate reminder
    const wt = (tot + 120) % 1440;
    const wStr = `${p2(Math.floor(wt / 60))}:${p2(wt % 60)}`;
    if (wStr === cur) due.push({ ar: { title: `موعد ماء — الجلسة ${i + 1} 💧`, body: "أعطِ 200 مل ماء عبر الأنبوب — إجلاس المريض 40–45°" }, en: { title: `Water — Session ${i + 1} 💧`, body: "Give 200 ml water via the tube — seat patient at 40–45°" }, tag: "water" });
  }

  // Vitamin D monthly at 08:00 (two days before + on the day)
  if (cur === "08:00" && map.vitD_next) {
    const d = Math.ceil((new Date(String(map.vitD_next)).getTime() - new Date(todayQ).getTime()) / 86400000);
    if (d === 2) due.push({ ar: { title: "تذكير: فيتامين D بعد يومين", body: "جرعة فيتامين D الشهرية قريبًا" }, en: { title: "Reminder: Vitamin D in 2 days", body: "Monthly Vitamin D dose is coming up" }, tag: "vitd" });
    if (d <= 0) due.push({ ar: { title: "جرعة فيتامين D اليوم 💊", body: "أعطِ جرعة فيتامين D الشهرية عبر NGT" }, en: { title: "Vitamin D dose today 💊", body: "Give the monthly Vitamin D dose via NGT" }, tag: "vitd" });
  }

  // Fixed date reminders at 08:00 (two days before + on the day)
  if (cur === "08:00") {
    for (const r of DATE_REMINDERS) {
      const d = Math.ceil((new Date(r.date).getTime() - new Date(todayQ).getTime()) / 86400000);
      if (d === 2) due.push({ ar: { title: r.ar.title + " (بعد يومين)", body: r.ar.body }, en: { title: r.en.title + " (in 2 days)", body: r.en.body }, tag: "date" });
      if (d === 0) due.push({ ar: r.ar, en: r.en, tag: "date" });
    }
  }

  if (!due.length) return json({ cur, due: 0 });

  const { data: subs } = await sb.from("push_subscriptions").select("*");
  let sent = 0, removed = 0;
  for (const s of subs || []) {
    const subscription = { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } };
    const lang: "ar" | "en" = s.lang === "en" ? "en" : "ar"; // each device gets its user's chosen language
    for (const n of due) {
      const m = n[lang];
      try {
        await webpush.sendNotification(subscription, JSON.stringify({ title: m.title, body: m.body, tag: n.tag }));
        sent++;
      } catch (e: any) {
        const code = e?.statusCode;
        if (code === 404 || code === 410) { await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint); removed++; break; }
      }
    }
  }
  return json({ cur, due: due.length, sent, removed });
});

function json(o: unknown) {
  return new Response(JSON.stringify(o), { headers: { "content-type": "application/json" } });
}
