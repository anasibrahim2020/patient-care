// Supabase Edge Function: push-action
// Called by a database trigger whenever a new row is inserted into action_log.
// Sends a Web Push ("New entry: …") to every registered device EXCEPT the one
// that performed the action (matched by client_id), in each device's language.
//
// Function secrets (reuse the same ones as push-tick):
//   VAPID_PUBLIC_KEY · VAPID_PRIVATE_KEY · VAPID_SUBJECT · CRON_SECRET
// Deploy with "Verify JWT" OFF (protected by the CRON_SECRET header instead).

import webpush from "npm:web-push@3.6.7";
import { createClient } from "jsr:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VAPID_PUBLIC = Deno.env.get("VAPID_PUBLIC_KEY")!;
const VAPID_PRIVATE = Deno.env.get("VAPID_PRIVATE_KEY")!;
const VAPID_SUBJECT = Deno.env.get("VAPID_SUBJECT") || "mailto:care@careportal.com";
const CRON_SECRET = Deno.env.get("CRON_SECRET") || "";

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
const sb = createClient(SUPABASE_URL, SERVICE_KEY);

Deno.serve(async (req) => {
  if (CRON_SECRET && req.headers.get("x-cron-secret") !== CRON_SECRET) return new Response("forbidden", { status: 403 });

  let body: any = {};
  try { body = await req.json(); } catch (_) { /* ignore */ }
  const rec = body.record || body; // works with a raw {detail, client_id} body or a trigger's {record:{…}}
  const detail: string = rec.action_detail || rec.detail || "";
  const actor: string = rec.client_id || "";
  if (!detail) return json({ skipped: "no detail" });

  const { data: subs } = await sb.from("push_subscriptions").select("*");
  const titles: Record<string, string> = { ar: "تسجيل جديد", en: "New entry" };
  let sent = 0, removed = 0;
  for (const s of subs || []) {
    if (actor && s.client_id && s.client_id === actor) continue; // don't notify whoever performed the action
    const lang = s.lang === "en" ? "en" : "ar";
    const subscription = { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } };
    try {
      await webpush.sendNotification(subscription, JSON.stringify({ title: titles[lang], body: detail, tag: "carelog" }));
      sent++;
    } catch (e: any) {
      const code = e?.statusCode;
      if (code === 404 || code === 410) { await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint); removed++; }
    }
  }
  return json({ sent, removed });
});

function json(o: unknown) {
  return new Response(JSON.stringify(o), { headers: { "content-type": "application/json" } });
}
